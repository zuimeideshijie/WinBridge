"""Bottle (Wine prefix) management."""

import json
import re
import shlex
import shutil
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Dict

from . import registry
from .config import Config
from .sandbox import forget_prefix_cache
from .wine import Wine

# HKCU keys behind the two window switches. Values use single backslashes,
# the form Wine's own `reg` command expects.
X11_DRIVER_KEY = r"Software\Wine\X11 Driver"
DESKTOPS_KEY = r"Software\Wine\Explorer\Desktops"

# Environment type → display label (shared by every view showing a bottle)
ENVIRONMENT_LABELS = {
    "gaming": "游戏",
    "office": "办公",
    "custom": "自定义",
}

# Windows versions as Wine's `winecfg -v` understands them.
WINDOWS_VERSIONS = (
    "win11", "win10", "win81", "win8", "win7", "vista",
    "win2003", "winxp", "win2k", "winme", "win98", "win95",
)

# Only the versions whose Wine key is not the user-facing name. Everything
# else (win10, win7, winxp…) is shown as-is.
WINDOWS_VERSION_LABELS = {
    "win81": "win8.1",
    "win2k": "win2000",
}


def windows_version_label(value: str) -> str:
    """Display label for a stored Windows version key."""
    raw = (value or "").strip()
    return WINDOWS_VERSION_LABELS.get(raw, raw)


def environment_key(value: str) -> str:
    """Normalise a stored environment value to one of the known keys.

    Older bottles store the localised combo text (e.g.
    "游戏/多媒体 (gaming)") instead of the bare key, so match by substring.
    """
    raw = (value or "").lower()
    for key in ENVIRONMENT_LABELS:
        if key in raw:
            return key
    return "custom"


def environment_label(value: str) -> str:
    """Display label for a stored environment value."""
    return ENVIRONMENT_LABELS[environment_key(value)]


class Bottle:
    """Represents a single Wine prefix / bottle."""

    def __init__(self, path: str, name: str = None, config: Config = None):
        self.path = Path(path)
        self.config = config or Config()
        self.meta_file = self.path / "bottle.json"
        # Temporarily create Wine with default path; _load_meta() needs self.wine
        self.wine = Wine(self.config.wine_path)
        self._meta = self._load_meta()
        if name:
            self._meta["name"] = name
            self._save_meta()
        # Now update Wine to use the bottle-specific path if set in meta
        wp = self._meta.get("wine_path", "")
        if wp:
            self.wine = Wine(wp)

    def _load_meta(self) -> Dict:
        """Load bottle metadata."""
        default = {
            "name": self.path.name,
            "created": datetime.now().isoformat(),
            "modified": datetime.now().isoformat(),
            "arch": self.config.wine_arch,
            "windows_version": "win10",
            "description": "",
            "environment": "gaming",  # gaming, office, custom
            "version": self.wine.version,
            "wine_path": "",
            "sandbox": "host",  # host | flatpak (sandboxed graphics runtime)
            "installed_components": [],
            "dll_overrides": {},
            "component_records": {},
        }
        if self.meta_file.exists():
            try:
                with open(self.meta_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                default.update(data)
            except (json.JSONDecodeError, OSError):
                pass
        return default

    def _save_meta(self):
        """Save bottle metadata."""
        self._meta["modified"] = datetime.now().isoformat()
        self.meta_file.parent.mkdir(parents=True, exist_ok=True)
        with open(self.meta_file, "w", encoding="utf-8") as f:
            json.dump(self._meta, f, indent=2, ensure_ascii=False)

    @property
    def name(self) -> str:
        return self._meta.get("name", self.path.name)

    @name.setter
    def name(self, value: str):
        self._meta["name"] = value
        self._save_meta()

    @property
    def wine_path(self) -> str:
        """Get the bottle-specific Wine path, or the global default."""
        wp = self._meta.get("wine_path", "")
        return wp if wp else self.config.wine_path

    @wine_path.setter
    def wine_path(self, value: str):
        self._meta["wine_path"] = value
        self._save_meta()
        # Recreate Wine instance with the new path
        self.wine = Wine(value if value else self.config.wine_path)

    @property
    def sandbox(self) -> str:
        """Runtime this bottle runs on: "host" or "flatpak"."""
        return self._meta.get("sandbox", "host") or "host"

    @sandbox.setter
    def sandbox(self, value: str):
        self._meta["sandbox"] = value or "host"
        self._save_meta()
        forget_prefix_cache(str(self.path))

    @property
    def created(self) -> str:
        return self._meta.get("created", "")

    @property
    def modified(self) -> str:
        return self._meta.get("modified", "")

    @property
    def arch(self) -> str:
        return self._meta.get("arch", "win64")

    @property
    def windows_version(self) -> str:
        return self._meta.get("windows_version", "win10")

    @windows_version.setter
    def windows_version(self, value: str):
        self._meta["windows_version"] = value
        self._save_meta()
        self.wine.set_win_version(str(self.path), value)

    @property
    def description(self) -> str:
        return self._meta.get("description", "")

    @description.setter
    def description(self, value: str):
        self._meta["description"] = value
        self._save_meta()

    @property
    def environment(self) -> str:
        return self._meta.get("environment", "gaming")

    @environment.setter
    def environment(self, value: str):
        self._meta["environment"] = value
        self._save_meta()

    @property
    def installed_components(self) -> List[str]:
        return self._meta.get("installed_components", [])

    @property
    def shortcuts(self) -> List[Dict]:
        """Remembered applications: name / target / source / icon.

        Kept in metadata rather than re-scanned every time so a program
        stays in the list after its Windows desktop shortcut is deleted.
        """
        return list(self._meta.get("shortcuts", []))

    @shortcuts.setter
    def shortcuts(self, value: List[Dict]):
        self._meta["shortcuts"] = list(value)
        self._save_meta()

    def forget_shortcut(self, target: str) -> bool:
        """Drop one shortcut from the bottle's list (program files untouched)."""
        items = [s for s in self.shortcuts if s.get("target") != target]
        if len(items) == len(self.shortcuts):
            return False
        self.shortcuts = items
        return True

    @property
    def hidden_shortcuts(self) -> List[str]:
        """Targets the user removed by hand.

        Discovery rescans the container every time the list is (re)loaded, so
        without this a removed entry would come straight back.
        """
        return list(self._meta.get("hidden_shortcuts", []))

    def hide_shortcut(self, target: str) -> bool:
        """Keep a removed shortcut out of future discovery passes."""
        hidden = self.hidden_shortcuts
        if not target or target in hidden:
            return False
        hidden.append(target)
        self._meta["hidden_shortcuts"] = hidden
        self._save_meta()
        return True

    def unhide_shortcut(self, target: str) -> bool:
        """Allow a previously removed shortcut to be discovered again."""
        hidden = self.hidden_shortcuts
        if target not in hidden:
            return False
        self._meta["hidden_shortcuts"] = [t for t in hidden if t != target]
        self._save_meta()
        return True

    def forget_shortcuts_under(self, root) -> int:
        """Drop every shortcut whose program lives inside `root`.

        Used after deleting an application folder: the app's own entries
        (updater, uninstaller, translator…) all die with it, so leaving them
        behind produces "程序文件不存在" on every double-click.
        Returns how many records were removed.
        """
        try:
            root_path = Path(root).resolve()
        except (OSError, ValueError):
            return 0
        keep, dropped = [], 0
        for entry in self.shortcuts:
            target = entry.get("target") or ""
            try:
                inside = bool(target) and Path(target).resolve().is_relative_to(root_path)
            except (OSError, ValueError):
                inside = False
            if inside:
                dropped += 1
            else:
                keep.append(entry)
        if dropped:
            self.shortcuts = keep
        return dropped

    def add_shortcut(self, name: str, target: str, source: str = "exe",
                     icon: str = "") -> bool:
        """Register a program in the shortcut list.

        Returns False when the same target is already listed, so clicking
        "添加程序" twice on one exe does not create duplicates.
        """
        items = self.shortcuts
        if any(item.get("target") == target for item in items):
            return False
        # An explicit add overrides an earlier "delete shortcut".
        self.unhide_shortcut(target)
        items.append({"name": name, "target": target,
                      "source": source, "icon": icon})
        self.shortcuts = items
        return True

    def rename_shortcut(self, target: str, new_name: str) -> bool:
        """Rename a shortcut's display name (the program file is untouched)."""
        items = self.shortcuts
        for item in items:
            if item.get("target") == target:
                item["name"] = new_name
                self.shortcuts = items
                return True
        return False

    def shortcut_args(self, target: str) -> List[str]:
        """Launch arguments remembered for one shortcut (empty when unset)."""
        for item in self.shortcuts:
            if item.get("target") == target:
                return [str(arg) for arg in (item.get("args") or [])]
        return []

    def set_shortcut_args(self, target: str, args: List[str]) -> bool:
        """Persist launch arguments for one shortcut.

        Stored as a list so quoting survives a save/load round trip; an empty
        list drops the key entirely, keeping bottle.json tidy.
        """
        items = self.shortcuts
        for item in items:
            if item.get("target") == target:
                cleaned = [str(arg) for arg in (args or []) if str(arg)]
                if cleaned:
                    item["args"] = cleaned
                else:
                    item.pop("args", None)
                self.shortcuts = items
                return True
        return False

    def launch_shortcut(self, target: str) -> bool:
        """Run a shortcut with the arguments it remembers."""
        return self.run(target, self.shortcut_args(target) or None)

    # ------------------------------------------------------------------
    # window options (winecfg's "Decorated" / "virtual desktop")
    # ------------------------------------------------------------------
    def _hkcu_value(self, key: str, name: str) -> str:
        """Read one HKCU value straight out of user.reg.

        Avoids spawning Wine just to paint a checkbox. The flip side is that a
        value written a moment ago may still only live in the running
        wineserver's memory, so callers should trust their own last write.
        """
        reg_file = self.path / "user.reg"
        if not reg_file.exists():
            return ""
        try:
            text = reg_file.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return ""
        tree_path = "HKCU" + registry.SEP + key.replace("\\", registry.SEP)
        for entry in registry.parse_values(text, tree_path):
            if entry.get("name") == name:
                return entry.get("data", "")
        return ""

    def _run_reg(self, command: str) -> tuple:
        """Run one ``reg`` command inside this bottle."""
        try:
            result = self.wine.run_cmd(str(self.path), command, timeout=60,
                                       env={"WINEDEBUG": "-all"})
        except Exception as error:  # noqa: BLE001 - shown to the user
            return False, str(error)
        if result.returncode == 0:
            return True, ""
        lines = [line.strip() for line in
                 (result.stderr or result.stdout or "").splitlines()
                 if line.strip()]
        # Wine prints its own chatter ("wineserver: using server-side
        # synchronization.", lsteamclient fixmes); the real complaint is the
        # line reg itself writes.
        message = next((line for line in reversed(lines)
                        if line.lower().startswith("reg:")),
                       lines[-1] if lines else "")
        return False, message[:300] or "wine reg 返回非零"

    @staticmethod
    def _reg_key(key: str) -> str:
        """Full path for Wine's ``reg``: it needs the hive, the .reg files not."""
        return key if key.upper().startswith("HKCU\\") else f"HKCU\\{key}"

    def _set_hkcu_value(self, key: str, name: str, data: str) -> tuple:
        return self._run_reg(
            f"reg add {shlex.quote(self._reg_key(key))} "
            f"/v {shlex.quote(name)} /t REG_SZ /d {shlex.quote(data)} /f")

    def _delete_hkcu_value(self, key: str, name: str) -> tuple:
        ok, error = self._run_reg(
            f"reg delete {shlex.quote(self._reg_key(key))} "
            f"/v {shlex.quote(name)} /f")
        if ok or not self._hkcu_value(key, name):
            # Wine errors out when the value isn't there; already-off is fine.
            return True, ""
        return False, error

    @property
    def window_decorated(self) -> bool:
        """Whether the window manager draws the titlebar (Wine default: yes)."""
        value = (self._hkcu_value(X11_DRIVER_KEY, "Decorated") or "Y").strip()
        return value.upper() != "N"

    def set_window_decorated(self, enabled: bool) -> tuple:
        """Turn WM titlebars on/off for this bottle (`Decorated`)."""
        return self._set_hkcu_value(X11_DRIVER_KEY, "Decorated",
                                    "Y" if enabled else "N")

    @property
    def virtual_desktop(self) -> str:
        """Virtual desktop size such as "1920x1080"; empty when disabled."""
        return (self._hkcu_value(DESKTOPS_KEY, "Default") or "").strip()

    def set_virtual_desktop(self, size: str) -> tuple:
        """Enable (``WxH``) or disable the virtual desktop for this bottle."""
        size = (size or "").strip().lower().replace("×", "x")
        if not size:
            return self._delete_hkcu_value(DESKTOPS_KEY, "Default")
        if not re.fullmatch(r"\d{3,5}x\d{3,5}", size):
            return False, "虚拟桌面尺寸格式应为 宽x高，例如 1920x1080。"
        return self._set_hkcu_value(DESKTOPS_KEY, "Default", size)

    @property
    def dll_overrides(self) -> Dict[str, str]:
        return self._meta.get("dll_overrides", {})

    @property
    def exists(self) -> bool:
        return self.path.exists() and (self.path / "user.reg").exists()

    @property
    def drive_c_size(self) -> str:
        """Get size of drive_c directory."""
        drive_c = self.path / "drive_c"
        if drive_c.exists():
            total = sum(f.stat().st_size for f in drive_c.rglob("*")
                        if f.is_file())
            for unit in ["B", "KB", "MB", "GB"]:
                if total < 1024:
                    return f"{total:.1f} {unit}"
                total /= 1024
            return f"{total:.1f} TB"
        return "0 B"

    def get_config(self) -> Dict:
        """Get full bottle configuration."""
        return {
            "name": self.name,
            "arch": self.arch,
            "windows_version": self.windows_version,
            "environment": self.environment,
            "description": self.description,
            "created": self.created,
            "modified": self.modified,
            "wine_version": self._meta.get("version", "unknown"),
            "wine_path": self.wine_path,
            "path": str(self.path),
            "size": self.drive_c_size,
            "installed_components": self.installed_components,
            "dll_overrides": self.dll_overrides,
        }

    def add_component(self, name: str):
        """Mark a component as installed."""
        if name not in self._meta["installed_components"]:
            self._meta["installed_components"].append(name)
            self._save_meta()

    def remove_component(self, name: str):
        """Mark a component as uninstalled."""
        if name in self._meta["installed_components"]:
            self._meta["installed_components"].remove(name)
            self._save_meta()

    @property
    def component_records(self) -> Dict[str, Dict]:
        """What each component put into the container.

        {"dxvk": {"files": ["system32/d3d11.dll", ...],
                  "overrides": {"d3d11": "native", ...}}}
        Files are relative to drive_c/windows. Components without a record
        (winetricks verbs, MSI installers) cannot be reverted file by file.
        """
        return self._meta.get("component_records", {})

    def get_component_record(self, name: str) -> Dict:
        return self.component_records.get(name, {})

    def set_component_record(self, name: str, files: List[str],
                             overrides: Dict[str, str]):
        """Remember the files/overrides a component installed."""
        self._meta.setdefault("component_records", {})[name] = {
            "files": list(files or []),
            "overrides": dict(overrides or {}),
        }
        self._save_meta()

    def drop_component_record(self, name: str):
        records = self._meta.get("component_records", {})
        if records.pop(name, None) is not None:
            self._save_meta()

    def component_overrides(self, exclude: str = None) -> List[str]:
        """DLL names still needed by components other than `exclude`."""
        names = []
        for component, record in self.component_records.items():
            if component == exclude:
                continue
            names.extend(record.get("overrides", {}))
        return names

    def set_dll_override(self, dll: str, mode: str):
        """Set a DLL override (native, builtin, native,builtin, etc.)."""
        self._meta["dll_overrides"][dll] = mode
        self._save_meta()

    def remove_dll_override(self, dll: str):
        """Remove a DLL override."""
        self._meta["dll_overrides"].pop(dll, None)
        self._save_meta()

    def set_registry(self, key: str, value_name: str, value_type: str,
                     value_data: str, hive: str = "HKCU"):
        """Set a registry value."""
        reg_path = self.path / f"{hive.lower()}.reg"
        # Use wine reg add
        self.wine.reg(str(self.path), str(reg_path))

    def delete(self):
        """Delete the bottle and all its data.

        Kills the wineserver and *waits* for it to exit (so file handles
        are released), then removes the prefix directory and verifies the
        removal actually succeeded. Without the wait/verify, a residual
        directory containing user.reg would make list_bottles() show the
        deleted bottle again moments later.
        """
        if not self.path.exists():
            return True
        try:
            self.wine.kill(str(self.path))
        except Exception:
            pass
        # Retry removal a few times; a just-killed wineserver may still be
        # flushing files on the first attempt.
        for attempt in range(3):
            try:
                shutil.rmtree(str(self.path))
            except OSError:
                import time
                time.sleep(1)
            if not self.path.exists():
                # Give a SIGKILLed wineserver a moment to die — if it was
                # still alive it cannot flush, but double-check no registry
                # files were recreated in the meantime.
                import time
                time.sleep(1.5)
                if not self.path.exists():
                    return True
        # Removal failed — don't silently leave a zombie bottle behind.
        raise OSError(f"删除容器失败，目录仍存在: {self.path}")

    def run(self, executable: str, args: list = None) -> bool:
        """Run an executable in the bottle.

        The working directory is the program's own folder: engines from the
        Win9x/XP era (Virtools, many installers) resolve their data files
        relative to it, so launching from WinBridge's own cwd makes them
        report "failed to initialize player" with every asset missing.
        """
        if not self.exists:
            return False
        workdir = None
        try:
            exe_path = Path(executable)
            if exe_path.is_file():
                workdir = str(exe_path.parent)
        except (OSError, ValueError):
            workdir = None
        result = self.wine.run(str(self.path), executable, args,
                               workdir=workdir, wait=False)
        return True


class BottleManager:
    """Manages all bottles."""

    def __init__(self, config: Config = None):
        self.config = config or Config()
        self.wine = Wine(self.config.wine_path)

    @property
    def bottles_dir(self) -> Path:
        return self.config.bottles_dir

    def list_bottles(self) -> List[Bottle]:
        """List all available bottles."""
        bottles = []
        if not self.bottles_dir.exists():
            return bottles
        for item in sorted(self.bottles_dir.iterdir()):
            if item.is_dir():
                bottle = Bottle(str(item), config=self.config)
                if bottle.exists:
                    bottles.append(bottle)
        return bottles

    def get_bottle(self, name: str) -> Optional[Bottle]:
        """Get a bottle by name."""
        path = self.bottles_dir / name
        if path.exists():
            return Bottle(str(path), config=self.config)
        return None

    def create_bottle(self, name: str, arch: str = "win64",
                      environment: str = "gaming",
                      windows_version: str = "win10",
                      description: str = "",
                      wine_path: str = "",
                      sandbox: str = "host") -> Optional[Bottle]:
        """Create a new bottle.

        `sandbox="flatpak"` creates the prefix with the flatpak runtime's
        libraries (its own Mesa/Vulkan) instead of the host ones; everything
        else — prefix path, Wine binary, programs — stays on the host.
        """
        bottle_path = self.bottles_dir / name
        if bottle_path.exists():
            return None

        # Use custom Wine path if specified
        wine = Wine(wine_path) if wine_path else self.wine

        # Create the Wine prefix
        success = wine.create_prefix(str(bottle_path), arch, sandbox=sandbox)
        if not success:
            return None

        # Inject host CJK + core Latin fonts so Wine apps can render
        # Chinese/Japanese/Korean characters instead of tofu boxes.
        wine.inject_fonts(str(bottle_path))

        # Create bottle metadata
        bottle = Bottle(str(bottle_path), name=name, config=self.config)
        bottle._meta["arch"] = arch
        bottle._meta["environment"] = environment
        bottle._meta["windows_version"] = windows_version
        bottle._meta["description"] = description
        bottle._meta["version"] = wine.version
        bottle._meta["sandbox"] = sandbox or "host"
        if wine_path:
            bottle._meta["wine_path"] = wine_path
        bottle._save_meta()

        # Set Windows version
        bottle.windows_version = windows_version

        return bottle

    def delete_bottle(self, name: str) -> bool:
        """Delete a bottle by name."""
        bottle = self.get_bottle(name)
        if bottle:
            bottle.delete()
            return True
        return False

    def rename_bottle(self, old_name: str, new_name: str) -> bool:
        """Rename a bottle."""
        old_path = self.bottles_dir / old_name
        new_path = self.bottles_dir / new_name
        if not old_path.exists() or new_path.exists():
            return False
        old_path.rename(new_path)
        bottle = Bottle(str(new_path), config=self.config)
        bottle.name = new_name
        return True

    def duplicate_bottle(self, name: str, new_name: str) -> Optional[Bottle]:
        """Duplicate a bottle."""
        src = self.bottles_dir / name
        dst = self.bottles_dir / new_name
        if not src.exists() or dst.exists():
            return None
        shutil.copytree(str(src), str(dst))
        bottle = Bottle(str(dst), name=new_name, config=self.config)
        bottle._meta["created"] = datetime.now().isoformat()
        bottle._save_meta()
        return bottle